package com.koreait.test21072901.model.service.hardware;

import java.util.List;

public interface HardwareService {
	public List selectAll();
}
