package com.koreait.test21072901.model.repository.hardware;

import java.util.List;

public interface HardwareDAO {
	public List selectAll();
}
