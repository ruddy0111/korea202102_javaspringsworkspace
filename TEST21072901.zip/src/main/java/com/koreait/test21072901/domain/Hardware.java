package com.koreait.test21072901.domain;

import lombok.Data;

@Data
public class Hardware {
	private int hardware_id;
	private String name;
	private String brand;
	private int price;
}
